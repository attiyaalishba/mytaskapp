// ApplyFragment.java placeholder content
